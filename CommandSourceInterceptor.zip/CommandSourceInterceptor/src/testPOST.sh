curl -X POST -H "Content-Type: application/json" -d @data.json http://localhost:9090/test/interceptor


#Sample of data.json file
#{
#	"first_name":"Heinz",
#	"last_name":"Schaffner",
#	"customer_id":1234567890
#}

